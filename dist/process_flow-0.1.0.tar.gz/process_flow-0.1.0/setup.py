# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['process_flow']

package_data = \
{'': ['*']}

install_requires = \
['plotly>=4.14.3,<5.0.0']

setup_kwargs = {
    'name': 'process-flow',
    'version': '0.1.0',
    'description': 'A library to create data flow process charts.',
    'long_description': None,
    'author': 'Levi Waddingham',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
